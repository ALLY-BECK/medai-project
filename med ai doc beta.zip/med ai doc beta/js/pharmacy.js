// ═══════════════════════════════════════════════
// pharmacy.js — Pharmacist QR Prescription
// ═══════════════════════════════════════════════

const RECENT_PRESCRIPTIONS = [
    { name: 'Айгерим Сейткали', meds: 'Амоксициллин 500мг', time: '09:15', status: 'dispensed' },
    { name: 'Болат Жаксыбеков', meds: 'Лозартан 50мг, Аторвастатин', time: '10:30', status: 'dispensed' },
    { name: 'Дина Мухамедова', meds: 'Метформин 1000мг', time: '11:00', status: 'dispensed' },
];

const MOCK_PRESCRIPTION = {
    patient: 'Ерлан Касымов',
    iin: '8812034521',
    doctor: 'Нурланова А.С.',
    date: '18.02.2026',
    valid: '25.02.2026',
    meds: [
        { name: 'Ибупрофен 400мг', dose: '1 таб. 3 раза в день, 7 дней' },
        { name: 'Мидокалм 150мг', dose: '1 таб. 2 раза в день, 10 дней' },
        { name: 'Диклофенак гель 1%', dose: 'Наружно 2-3 раза в день' },
    ],
};

function initPharmacy() {
    renderRecentPrescriptions();
}

function renderRecentPrescriptions() {
    const list = document.getElementById('recent-prescriptions');
    list.innerHTML = RECENT_PRESCRIPTIONS.map(rx => `
    <div class="recent-rx-item">
      <div class="recent-rx-icon">💊</div>
      <div class="recent-rx-info">
        <div class="recent-rx-name">${rx.name}</div>
        <div class="recent-rx-time">${rx.meds} · ${rx.time}</div>
      </div>
      <span class="badge badge-green">Выдан</span>
    </div>
  `).join('');
}

function simulateScan() {
    const area = document.getElementById('qr-scanner-area');
    area.style.background = 'rgba(16,185,129,0.1)';
    area.style.border = '1px solid rgba(16,185,129,0.3)';
    setTimeout(() => {
        showPrescription();
        area.style.background = '';
        area.style.border = '';
    }, 1200);
}

function showPrescription() {
    const rx = MOCK_PRESCRIPTION;
    const result = document.getElementById('prescription-result');
    const details = document.getElementById('prescription-details');
    details.innerHTML = `
    <div class="record-info-grid" style="margin-bottom:16px">
      <div class="record-info-item">
        <div class="record-info-label">Пациент</div>
        <div class="record-info-value">${rx.patient}</div>
      </div>
      <div class="record-info-item">
        <div class="record-info-label">ИИН</div>
        <div class="record-info-value" style="font-family:monospace">${rx.iin}</div>
      </div>
      <div class="record-info-item">
        <div class="record-info-label">Врач</div>
        <div class="record-info-value">${rx.doctor}</div>
      </div>
      <div class="record-info-item">
        <div class="record-info-label">Действителен до</div>
        <div class="record-info-value">${rx.valid}</div>
      </div>
    </div>
    <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:10px">Препараты</div>
    ${rx.meds.map(m => `
      <div class="rx-item">
        <div>
          <div class="rx-name">${m.name}</div>
          <div class="rx-dose">${m.dose}</div>
        </div>
      </div>
    `).join('')}
  `;
    result.style.display = 'block';
    result.style.animation = 'fadeInUp 0.3s ease';
}

function dispenseRx() {
    showToast('✅ Лекарства выданы пациенту');
    document.getElementById('prescription-result').style.display = 'none';
    RECENT_PRESCRIPTIONS.unshift({ name: MOCK_PRESCRIPTION.patient, meds: MOCK_PRESCRIPTION.meds[0].name, time: '22:30', status: 'dispensed' });
    renderRecentPrescriptions();
}
