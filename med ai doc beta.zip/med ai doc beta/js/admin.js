// ═══════════════════════════════════════════════
// admin.js — Medical Staff / Admin Dashboard
// ═══════════════════════════════════════════════

const SCHEDULE_DATA = [
    { name: 'Нурланова Асель', spec: 'Терапевт', time: '08:00 – 17:00', initials: 'АН', color: 'linear-gradient(135deg,#2563EB,#8B5CF6)' },
    { name: 'Сейткали Марат', spec: 'Хирург', time: '09:00 – 18:00', initials: 'СМ', color: 'linear-gradient(135deg,#10B981,#06B6D4)' },
    { name: 'Бекова Гульнара', spec: 'Педиатр', time: '08:00 – 16:00', initials: 'БГ', color: 'linear-gradient(135deg,#F59E0B,#EF4444)' },
    { name: 'Касымов Руслан', spec: 'Кардиолог', time: '10:00 – 19:00', initials: 'КР', color: 'linear-gradient(135deg,#EF4444,#8B5CF6)' },
    { name: 'Жаксыбекова Айна', spec: 'Невролог', time: '08:00 – 17:00', initials: 'ЖА', color: 'linear-gradient(135deg,#06B6D4,#2563EB)' },
];

let ANNOUNCEMENTS = [
    { text: 'Плановое техническое обслуживание МРТ-аппарата 20 февраля с 08:00 до 14:00. Запись на МРТ временно недоступна.', author: 'Администрация', time: '17.02.2026' },
    { text: 'Напоминаем о ежегодной диспансеризации сотрудников. Запись у медсестры Айгуль до 28 февраля.', author: 'Администрация', time: '15.02.2026' },
    { text: 'Поздравляем доктора Нурланову А.С. с победой в конкурсе "Лучший врач месяца"!', author: 'Главный врач', time: '10.02.2026' },
];

function initAdmin() {
    renderSchedule();
    renderAnnouncements();
}

function renderSchedule() {
    document.getElementById('admin-schedule').innerHTML = SCHEDULE_DATA.map(s => `
    <div class="schedule-item">
      <div class="schedule-avatar" style="background:${s.color}">${s.initials}</div>
      <div class="schedule-info">
        <div class="schedule-name">${s.name}</div>
        <div class="schedule-spec">${s.spec}</div>
      </div>
      <div class="schedule-time">${s.time}</div>
    </div>
  `).join('');
}

function renderAnnouncements() {
    document.getElementById('announcements-list').innerHTML = ANNOUNCEMENTS.map(a => `
    <div class="announcement-item">
      <div class="announcement-text">${a.text}</div>
      <div class="announcement-meta">${a.author} · ${a.time}</div>
    </div>
  `).join('');
}

function publishAnnouncement() {
    const text = document.getElementById('announcement-text').value.trim();
    if (!text) { showToast('Введите текст объявления', 'error'); return; }
    ANNOUNCEMENTS.unshift({ text, author: 'Администрация', time: '18.02.2026' });
    renderAnnouncements();
    document.getElementById('announcement-text').value = '';
    showToast('✅ Объявление опубликовано');
}
