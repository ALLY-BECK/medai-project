// ═══════════════════════════════════════════════
// app.js — Router, State, Utilities
// ═══════════════════════════════════════════════

const AppState = {
  role: null,
  user: null,
  selectedPatient: null,
  appointmentActive: false,
  appointmentTimer: null,
  appointmentSeconds: 0,
};

const ROLE_CONFIG = {
  doctor: {
    name: 'Доктор Асель Нурланова',
    initials: 'АН',
    label: 'Врач — Терапевт',
    nav: [
      { id: 'dashboard', icon: '🏠', label: 'Дашборд' },
      { id: 'patients', icon: '👥', label: 'Пациенты' },
      { id: 'appointment', icon: '🩺', label: 'Приём' },
    ],
    home: 'dashboard',
  },
  admin: {
    name: 'Администратор Клиники',
    initials: 'АК',
    label: 'Мед персонал',
    nav: [
      { id: 'admin', icon: '🏥', label: 'Управление' },
      { id: 'patients', icon: '👥', label: 'Пациенты' },
    ],
    home: 'admin',
  },
  pharmacy: {
    name: 'Аптекарь Данияр',
    initials: 'ДА',
    label: 'Аптека №3',
    nav: [
      { id: 'pharmacy', icon: '💊', label: 'Рецепты' },
    ],
    home: 'pharmacy',
  },
  lab: {
    name: 'Лаборант Айгерим',
    initials: 'АЛ',
    label: 'Лаборатория',
    nav: [
      { id: 'lab', icon: '🔬', label: 'Анализы' },
    ],
    home: 'lab',
  },
  ministry: {
    name: 'Инспектор Минздрав',
    initials: 'МЗ',
    label: 'Министерство здравоохранения',
    nav: [
      { id: 'ministry', icon: '🏛️', label: 'Статистика' },
    ],
    home: 'ministry',
  },
};

function navigateTo(pageId) {
  document.querySelectorAll('.content-page').forEach(p => p.style.display = 'none');
  const page = document.getElementById('page-' + pageId);
  if (page) {
    page.style.display = 'block';
    page.style.animation = 'none';
    requestAnimationFrame(() => { page.style.animation = 'fadeInUp 0.4s ease'; });
  }
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === pageId);
  });
  // Init page
  if (pageId === 'dashboard') initDashboard();
  if (pageId === 'patients') initPatients();
  if (pageId === 'pharmacy') initPharmacy();
  if (pageId === 'lab') initLab();
  if (pageId === 'ministry') initMinistry();
  if (pageId === 'admin') initAdmin();
}

function loginAs(role) {
  AppState.role = role;
  const cfg = ROLE_CONFIG[role];
  AppState.user = cfg;

  document.getElementById('page-auth').style.display = 'none';
  const shell = document.getElementById('app-shell');
  shell.style.display = 'flex';

  // Set user info
  document.getElementById('sidebar-user-name').textContent = cfg.name;
  document.getElementById('sidebar-user-role').textContent = cfg.label;
  document.getElementById('sidebar-avatar').textContent = cfg.initials;

  // Build nav
  const nav = document.getElementById('sidebar-nav');
  nav.innerHTML = cfg.nav.map(item => `
    <button class="nav-item" data-page="${item.id}" onclick="navigateTo('${item.id}')">
      <span class="nav-icon">${item.icon}</span>
      ${item.label}
    </button>
  `).join('');

  navigateTo(cfg.home);
}

function handleLogout() {
  AppState.role = null;
  AppState.selectedPatient = null;
  document.getElementById('app-shell').style.display = 'none';
  document.getElementById('page-auth').style.display = 'flex';
  document.querySelectorAll('.role-card').forEach(c => c.classList.remove('active'));
  document.getElementById('auth-form').reset();
  document.getElementById('login-btn').disabled = true;
  document.getElementById('selected-role-badge').style.display = 'none';
}

function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast' + (type === 'error' ? ' error' : '');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

function formatTime(date) {
  return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(date) {
  return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
}

function closeModal(e) {
  if (e.target === e.currentTarget) {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
  }
}

// Gradient colors for avatars
const AVATAR_GRADIENTS = [
  'linear-gradient(135deg,#2563EB,#8B5CF6)',
  'linear-gradient(135deg,#06B6D4,#2563EB)',
  'linear-gradient(135deg,#10B981,#06B6D4)',
  'linear-gradient(135deg,#F59E0B,#EF4444)',
  'linear-gradient(135deg,#8B5CF6,#EC4899)',
  'linear-gradient(135deg,#EF4444,#F59E0B)',
];
function avatarGrad(i) { return AVATAR_GRADIENTS[i % AVATAR_GRADIENTS.length]; }
