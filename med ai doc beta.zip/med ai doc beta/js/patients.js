// ═══════════════════════════════════════════════
// patients.js — Patient Search & Medical Records
// ═══════════════════════════════════════════════

const PATIENTS_DATA = [
    {
        id: 0, name: 'Айгерим Сейткали', initials: 'АС', iin: '9203154521', dob: '15.03.1992',
        blood: 'A(II) Rh+', gender: 'Женский', phone: '+7 701 234 5678',
        chronic: ['Хронический гастрит', 'Анемия лёгкой степени'],
        allergies: [{ name: 'Пенициллин', level: 'high' }, { name: 'Пыльца берёзы', level: 'med' }],
        illnesses: [
            { name: 'ОРВИ', date: 'Январь 2026' },
            { name: 'Острый бронхит', date: 'Март 2025' },
            { name: 'Гастрит обострение', date: 'Октябрь 2024' },
        ],
        tags: ['Гастрит', 'Анемия'],
    },
    {
        id: 1, name: 'Болат Жаксыбеков', initials: 'БЖ', iin: '8501234567', dob: '12.01.1985',
        blood: 'O(I) Rh+', gender: 'Мужской', phone: '+7 702 345 6789',
        chronic: ['Гипертония II степени', 'Ожирение I степени'],
        allergies: [{ name: 'Аспирин', level: 'high' }],
        illnesses: [
            { name: 'Гипертонический криз', date: 'Декабрь 2025' },
            { name: 'ОРВИ', date: 'Сентябрь 2025' },
        ],
        tags: ['Гипертония', 'Ожирение'],
    },
    {
        id: 2, name: 'Дина Мухамедова', initials: 'ДМ', iin: '9507281234', dob: '28.07.1995',
        blood: 'B(III) Rh-', gender: 'Женский', phone: '+7 707 456 7890',
        chronic: ['Сахарный диабет 2 типа'],
        allergies: [{ name: 'Мёд', level: 'low' }, { name: 'Орехи', level: 'med' }],
        illnesses: [
            { name: 'Диабетическая нейропатия', date: 'Ноябрь 2025' },
            { name: 'ОРВИ', date: 'Август 2025' },
        ],
        tags: ['Диабет'],
    },
    {
        id: 3, name: 'Ерлан Касымов', initials: 'ЕК', iin: '8812034521', dob: '03.12.1988',
        blood: 'AB(IV) Rh+', gender: 'Мужской', phone: '+7 705 567 8901',
        chronic: ['Остеохондроз поясничного отдела'],
        allergies: [],
        illnesses: [
            { name: 'Радикулит', date: 'Февраль 2026' },
            { name: 'Растяжение мышц спины', date: 'Июль 2025' },
        ],
        tags: ['Остеохондроз'],
    },
    {
        id: 4, name: 'Жанар Бекова', initials: 'ЖБ', iin: '0004152345', dob: '15.04.2000',
        blood: 'A(II) Rh-', gender: 'Женский', phone: '+7 708 678 9012',
        chronic: ['Аллергический ринит', 'Атопический дерматит'],
        allergies: [{ name: 'Кошачья шерсть', level: 'high' }, { name: 'Пыльца', level: 'high' }, { name: 'Цитрусовые', level: 'med' }],
        illnesses: [
            { name: 'Аллергический ринит обострение', date: 'Февраль 2026' },
            { name: 'Крапивница', date: 'Май 2025' },
        ],
        tags: ['Аллергия', 'Дерматит'],
    },
    {
        id: 5, name: 'Зарина Алиева', initials: 'ЗА', iin: '9309234512', dob: '23.09.1993',
        blood: 'O(I) Rh+', gender: 'Женский', phone: '+7 701 789 0123',
        chronic: [],
        allergies: [{ name: 'Латекс', level: 'med' }],
        illnesses: [
            { name: 'Плановый осмотр', date: 'Февраль 2026' },
            { name: 'ОРВИ', date: 'Декабрь 2025' },
        ],
        tags: ['Здоров'],
    },
    {
        id: 6, name: 'Нурлан Сейткали', initials: 'НС', iin: '7806124523', dob: '12.06.1978',
        blood: 'B(III) Rh+', gender: 'Мужской', phone: '+7 702 890 1234',
        chronic: ['Хронический бронхит', 'Гипертония I степени'],
        allergies: [{ name: 'Сульфаниламиды', level: 'high' }],
        illnesses: [
            { name: 'Обострение бронхита', date: 'Февраль 2026' },
            { name: 'Пневмония', date: 'Январь 2025' },
        ],
        tags: ['Бронхит', 'Гипертония'],
    },
    {
        id: 7, name: 'Мадина Ержанова', initials: 'МЕ', iin: '9112034521', dob: '03.12.1991',
        blood: 'A(II) Rh+', gender: 'Женский', phone: '+7 707 901 2345',
        chronic: ['Мигрень', 'Вегетососудистая дистония'],
        allergies: [{ name: 'Кодеин', level: 'high' }],
        illnesses: [
            { name: 'Мигрень с аурой', date: 'Февраль 2026' },
            { name: 'Гипертонический криз', date: 'Октябрь 2025' },
        ],
        tags: ['Мигрень', 'ВСД'],
    },
    {
        id: 8, name: 'Асель Нурмагамбетова', initials: 'АН', iin: '9708234512', dob: '23.08.1997',
        blood: 'O(I) Rh-', gender: 'Женский', phone: '+7 705 012 3456',
        chronic: ['Железодефицитная анемия'],
        allergies: [],
        illnesses: [
            { name: 'Анемия тяжёлой степени', date: 'Январь 2026' },
        ],
        tags: ['Анемия'],
    },
    {
        id: 9, name: 'Тимур Абенов', initials: 'ТА', iin: '0106154523', dob: '15.06.2001',
        blood: 'AB(IV) Rh+', gender: 'Мужской', phone: '+7 708 123 4567',
        chronic: [],
        allergies: [{ name: 'Ибупрофен', level: 'low' }],
        illnesses: [
            { name: 'Перелом лучевой кости', date: 'Ноябрь 2025' },
            { name: 'ОРВИ', date: 'Сентябрь 2025' },
        ],
        tags: ['Здоров'],
    },
];

let filteredPatients = [...PATIENTS_DATA];

function initPatients() {
    document.getElementById('patient-search').value = '';
    filteredPatients = [...PATIENTS_DATA];
    renderPatients();
}

function searchPatients(query) {
    const q = query.toLowerCase().trim();
    filteredPatients = q
        ? PATIENTS_DATA.filter(p =>
            p.name.toLowerCase().includes(q) ||
            p.iin.includes(q) ||
            p.tags.some(t => t.toLowerCase().includes(q))
        )
        : [...PATIENTS_DATA];
    document.getElementById('search-count').textContent = filteredPatients.length + ' пациент' + (filteredPatients.length === 1 ? '' : filteredPatients.length < 5 ? 'а' : 'ов');
    renderPatients();
}

function renderPatients() {
    const grid = document.getElementById('patients-grid');
    document.getElementById('search-count').textContent = filteredPatients.length + ' пациент' + (filteredPatients.length === 1 ? '' : filteredPatients.length < 5 ? 'а' : 'ов');
    if (!filteredPatients.length) {
        grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px">Пациенты не найдены</div>';
        return;
    }
    grid.innerHTML = filteredPatients.map(p => `
    <div class="patient-card" onclick="openRecord(${p.id})">
      <div class="patient-avatar" style="background:${avatarGrad(p.id)}">${p.initials}</div>
      <div class="patient-info">
        <div class="patient-name">${p.name}</div>
        <div class="patient-iin">ИИН: ${p.iin}</div>
        <div class="patient-tags">
          ${p.tags.map(t => `<span class="badge badge-blue">${t}</span>`).join('')}
        </div>
      </div>
    </div>
  `).join('');
}

function openRecord(id) {
    const p = PATIENTS_DATA.find(x => x.id === id);
    if (!p) return;
    AppState.selectedPatient = p;
    const overlay = document.getElementById('record-overlay');
    const content = document.getElementById('record-content');

    const allergyLevelMap = { high: 'allergy-high', med: 'allergy-med', low: 'allergy-low' };
    const allergyLabelMap = { high: '⚠️ Высокая', med: '⚡ Средняя', low: '✓ Низкая' };

    content.innerHTML = `
    <div class="record-profile">
      <div class="record-avatar" style="background:${avatarGrad(p.id)}">${p.initials}</div>
      <div>
        <div class="record-name">${p.name}</div>
        <div class="record-meta">ИИН: ${p.iin} · ${p.blood}</div>
      </div>
    </div>

    <div class="record-section">
      <div class="record-section-title">Основная информация</div>
      <div class="record-info-grid">
        <div class="record-info-item">
          <div class="record-info-label">Дата рождения</div>
          <div class="record-info-value">${p.dob}</div>
        </div>
        <div class="record-info-item">
          <div class="record-info-label">Пол</div>
          <div class="record-info-value">${p.gender}</div>
        </div>
        <div class="record-info-item">
          <div class="record-info-label">Группа крови</div>
          <div class="record-info-value">${p.blood}</div>
        </div>
        <div class="record-info-item">
          <div class="record-info-label">Телефон</div>
          <div class="record-info-value">${p.phone}</div>
        </div>
      </div>
    </div>

    ${p.chronic.length ? `
    <div class="record-section">
      <div class="record-section-title">Хронические заболевания</div>
      ${p.chronic.map(c => `
        <div class="illness-item" style="margin-bottom:8px">
          <div class="illness-dot" style="background:var(--amber);box-shadow:0 0 8px rgba(245,158,11,0.5)"></div>
          <div class="illness-name">${c}</div>
        </div>
      `).join('')}
    </div>` : ''}

    ${p.allergies.length ? `
    <div class="record-section">
      <div class="record-section-title">Аллергии</div>
      <div class="allergy-list">
        ${p.allergies.map(a => `
          <span class="allergy-tag ${allergyLevelMap[a.level]}">${a.name} — ${allergyLabelMap[a.level]}</span>
        `).join('')}
      </div>
    </div>` : `
    <div class="record-section">
      <div class="record-section-title">Аллергии</div>
      <span class="badge badge-green">Аллергий не выявлено</span>
    </div>`}

    <div class="record-section">
      <div class="record-section-title">История болезней</div>
      <div class="illness-timeline">
        ${p.illnesses.map(ill => `
          <div class="illness-item">
            <div class="illness-dot"></div>
            <div>
              <div class="illness-name">${ill.name}</div>
              <div class="illness-date">${ill.date}</div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <div style="display:flex;gap:10px;margin-top:8px">
      <button class="btn btn-primary btn-full" onclick="goToAppointment(${p.id})">
        🩺 Начать приём
      </button>
    </div>
  `;

    overlay.style.display = 'flex';
}

function closeRecord(e) {
    if (!e || e.target === document.getElementById('record-overlay') || e.target.classList.contains('record-close')) {
        document.getElementById('record-overlay').style.display = 'none';
    }
}

function goToAppointment(id) {
    const p = PATIENTS_DATA.find(x => x.id === id);
    AppState.selectedPatient = p;
    document.getElementById('record-overlay').style.display = 'none';
    navigateTo('appointment');
    document.getElementById('appt-patient-name').textContent = p ? p.name : 'Пациент';
}
