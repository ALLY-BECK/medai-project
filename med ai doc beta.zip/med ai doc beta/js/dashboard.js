// ═══════════════════════════════════════════════
// dashboard.js — Doctor Dashboard
// ═══════════════════════════════════════════════

const APPOINTMENTS_DATA = [
    { time: '09:00', name: 'Айгерим Сейткали', initials: 'АС', diagnosis: 'ОРВИ, возможный грипп', status: 'done', id: 0 },
    { time: '09:30', name: 'Болат Жаксыбеков', initials: 'БЖ', diagnosis: 'Гипертония II степени', status: 'done', id: 1 },
    { time: '10:00', name: 'Дина Мухамедова', initials: 'ДМ', diagnosis: 'Сахарный диабет, контроль', status: 'done', id: 2 },
    { time: '10:30', name: 'Ерлан Касымов', initials: 'ЕК', diagnosis: 'Боли в пояснице, радикулит', status: 'current', id: 3 },
    { time: '11:00', name: 'Жанар Бекова', initials: 'ЖБ', diagnosis: 'Аллергический ринит', status: 'waiting', id: 4 },
    { time: '11:30', name: 'Зарина Алиева', initials: 'ЗА', diagnosis: 'Плановый осмотр', status: 'waiting', id: 5 },
    { time: '14:00', name: 'Нурлан Сейткали', initials: 'НС', diagnosis: 'Бронхит, кашель 2 недели', status: 'waiting', id: 6 },
    { time: '14:30', name: 'Мадина Ержанова', initials: 'МЕ', diagnosis: 'Мигрень, головные боли', status: 'waiting', id: 7 },
];

const NOTIFICATIONS_DATA = [
    {
        icon: '🏛️', type: 'ministry',
        title: 'Минздрав РК — Приказ №47',
        text: 'Обновлены протоколы лечения COVID-19 и ОРВИ. Ознакомьтесь с новыми клиническими рекомендациями до 25 февраля 2026.',
        time: '2 часа назад',
    },
    {
        icon: '🏥', type: 'clinic',
        title: 'Объявление клиники',
        text: 'Плановое техническое обслуживание МРТ-аппарата 20 февраля с 08:00 до 14:00. Запись на МРТ временно недоступна.',
        time: '5 часов назад',
    },
    {
        icon: '⚠️', type: 'alert',
        title: 'Напоминание о вакцинации',
        text: 'Пациент Болат Жаксыбеков (ИИН: 8501234567) не прошёл ревакцинацию от гепатита B. Рекомендуется направление.',
        time: 'Вчера, 16:30',
    },
    {
        icon: '🏛️', type: 'ministry',
        title: 'Минздрав — Статистика',
        text: 'Отчёт за январь 2026: заболеваемость ОРВИ снизилась на 12% по сравнению с прошлым годом.',
        time: 'Вчера, 09:00',
    },
];

function initDashboard() {
    const now = new Date(2026, 1, 18, 22, 29);
    const hour = now.getHours();
    let greeting = hour < 12 ? 'Доброе утро' : hour < 17 ? 'Добрый день' : 'Добрый вечер';
    const name = AppState.user ? AppState.user.name.split(' ')[1] : 'Доктор';
    document.getElementById('dashboard-greeting').textContent = `${greeting}, ${name}!`;
    document.getElementById('header-date').textContent = formatDate(now) + ' · ' + formatTime(now);

    renderAppointments();
    renderNotifications();
}

function renderAppointments() {
    const list = document.getElementById('appointments-list');
    list.innerHTML = APPOINTMENTS_DATA.map((a, i) => {
        const statusBadge = a.status === 'done'
            ? '<span class="badge badge-green">Завершён</span>'
            : a.status === 'current'
                ? '<span class="badge badge-amber">Идёт приём</span>'
                : '<span class="badge badge-blue">Ожидает</span>';
        return `
      <div class="appointment-item" onclick="openPatientFromDashboard(${a.id})">
        <span class="appt-time">${a.time}</span>
        <div class="appt-avatar" style="background:${avatarGrad(i)}">${a.initials}</div>
        <div class="appt-info">
          <div class="appt-name">${a.name}</div>
          <div class="appt-diagnosis">${a.diagnosis}</div>
        </div>
        <div class="appt-actions">${statusBadge}</div>
      </div>
    `;
    }).join('');
}

function renderNotifications() {
    const list = document.getElementById('notifications-list');
    list.innerHTML = NOTIFICATIONS_DATA.map(n => `
    <div class="notif-item">
      <div class="notif-icon notif-icon-${n.type}">${n.icon}</div>
      <div class="notif-body">
        <div class="notif-title">${n.title}</div>
        <div class="notif-text">${n.text}</div>
        <div class="notif-time">${n.time}</div>
      </div>
    </div>
  `).join('');
}

function openPatientFromDashboard(id) {
    const appt = APPOINTMENTS_DATA[id];
    const patient = PATIENTS_DATA ? PATIENTS_DATA.find(p => p.name === appt.name) || PATIENTS_DATA[id % PATIENTS_DATA.length] : null;
    if (patient) {
        AppState.selectedPatient = patient;
        navigateTo('patients');
        setTimeout(() => openRecord(patient.id), 300);
    }
}
