// ═══════════════════════════════════════════════
// laboratory.js — Lab Results Management
// ═══════════════════════════════════════════════

const LAB_PENDING = [
    { id: 1, type: 'Общий анализ крови', patient: 'Жанар Бекова', iin: '0004152345', time: '08:30', icon: '🩸', color: 'rgba(239,68,68,0.15)' },
    { id: 2, type: 'Биохимия крови', patient: 'Болат Жаксыбеков', iin: '8501234567', time: '09:00', icon: '🧪', color: 'rgba(37,99,235,0.15)' },
    { id: 3, type: 'ПЦР тест', patient: 'Нурлан Сейткали', iin: '7806124523', time: '09:30', icon: '🦠', color: 'rgba(139,92,246,0.15)' },
    { id: 4, type: 'Общий анализ мочи', patient: 'Дина Мухамедова', iin: '9507281234', time: '10:00', icon: '💧', color: 'rgba(6,182,212,0.15)' },
    { id: 5, type: 'Гормоны щитовидной железы', patient: 'Мадина Ержанова', iin: '9112034521', time: '10:30', icon: '⚗️', color: 'rgba(245,158,11,0.15)' },
];

const LAB_COMPLETED = [
    { type: 'Общий анализ крови', patient: 'Айгерим Сейткали', time: '07:45', icon: '🩸' },
    { type: 'Биохимия крови', patient: 'Ерлан Касымов', time: '08:00', icon: '🧪' },
    { type: 'ПЦР тест', patient: 'Зарина Алиева', time: '08:15', icon: '🦠' },
];

let pendingList = [...LAB_PENDING];
let completedList = [...LAB_COMPLETED];

function initLab() {
    renderLabLists();
}

function renderLabLists() {
    document.getElementById('pending-count').textContent = pendingList.length;
    document.getElementById('lab-pending-list').innerHTML = pendingList.map(item => `
    <div class="lab-item">
      <div class="lab-item-icon" style="background:${item.color}">${item.icon}</div>
      <div class="lab-item-info">
        <div class="lab-item-name">${item.type}</div>
        <div class="lab-item-patient">${item.patient} · ИИН: ${item.iin}</div>
        <div class="lab-item-time">Взят в ${item.time}</div>
      </div>
      <button class="btn btn-primary btn-sm" onclick="sendResult(${item.id})">Отправить</button>
    </div>
  `).join('') || '<div style="color:var(--text-muted);font-size:14px;padding:20px 0">Нет ожидающих анализов</div>';

    document.getElementById('lab-completed-list').innerHTML = completedList.map(item => `
    <div class="lab-item">
      <div class="lab-item-icon" style="background:rgba(16,185,129,0.15)">${item.icon}</div>
      <div class="lab-item-info">
        <div class="lab-item-name">${item.type}</div>
        <div class="lab-item-patient">${item.patient}</div>
        <div class="lab-item-time">Отправлен в ${item.time}</div>
      </div>
      <span class="badge badge-green">Отправлен</span>
    </div>
  `).join('');
}

function sendResult(id) {
    const idx = pendingList.findIndex(i => i.id === id);
    if (idx === -1) return;
    const item = pendingList.splice(idx, 1)[0];
    completedList.unshift({ type: item.type, patient: item.patient, time: '22:30', icon: item.icon });
    renderLabLists();
    showToast(`✅ Результат "${item.type}" отправлен ${item.patient}`);
}

function showAddResult() {
    document.getElementById('add-result-modal').style.display = 'flex';
}

function closeAddResult() {
    document.getElementById('add-result-modal').style.display = 'none';
}

function submitLabResult() {
    const iin = document.getElementById('lab-iin').value.trim();
    const type = document.getElementById('lab-type').value;
    const results = document.getElementById('lab-results').value.trim();
    if (!iin || !results) { showToast('Заполните все поля', 'error'); return; }
    completedList.unshift({ type, patient: 'ИИН: ' + iin, time: '22:30', icon: '🧪' });
    renderLabLists();
    closeAddResult();
    showToast('✅ Результат анализа отправлен пациенту');
    document.getElementById('lab-iin').value = '';
    document.getElementById('lab-results').value = '';
}
