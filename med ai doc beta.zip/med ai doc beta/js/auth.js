// ═══════════════════════════════════════════════
// auth.js — Role Selection & Login
// ═══════════════════════════════════════════════

let selectedRole = null;

const ROLE_LABELS = {
    doctor: '🩺 Врач',
    admin: '🏥 Мед персонал',
    pharmacy: '💊 Аптекарь',
    lab: '🔬 Лаборатория',
    ministry: '🏛️ Минздрав',
};

function selectRole(role) {
    selectedRole = role;
    document.querySelectorAll('.role-card').forEach(c => c.classList.remove('active'));
    document.querySelector(`[data-role="${role}"]`).classList.add('active');
    const badge = document.getElementById('selected-role-badge');
    badge.style.display = 'flex';
    badge.textContent = 'Выбрана роль: ' + ROLE_LABELS[role];
    document.getElementById('login-btn').disabled = false;
}

function handleLogin(e) {
    e.preventDefault();
    if (!selectedRole) { showToast('Выберите роль', 'error'); return; }
    const btn = document.getElementById('login-btn');
    btn.textContent = 'Вход...';
    btn.disabled = true;
    setTimeout(() => {
        loginAs(selectedRole);
        btn.innerHTML = '<span>Войти в систему</span>';
        btn.disabled = false;
    }, 800);
}
